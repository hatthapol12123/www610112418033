http://127.0.0.1/www/info.php

https://codeshare.io/5DKznm
<?php

phpinfo();

?> 